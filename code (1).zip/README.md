# Financial Affordability Agent

## Run

From the repository root:

```bash
python3 code/main.py
```

The program reads all participant-facing inputs from `dataset/` and writes:

```text
output.csv
```

to the repository root.

## Output validation

The program checks:
- exact required column order
- one prediction for every request
- unique request IDs
- `0 <= amount_safe_to_pay <= requested_amount`

No external API or secret is required.

## Submission files

- `code/main.py` — runnable solution
- `evaluation/usage_report.md` — final-run usage/cost report
- `output.csv` — predictions for all requests
